# TapForTap Android SDK

See https://tapfortap.com/doc/Android

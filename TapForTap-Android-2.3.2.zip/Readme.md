# TapForTap Android SDK

See http://tapfortap.com/doc/Android

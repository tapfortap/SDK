//
//  Copyright (c) 2013 Tap for Tap. All rights reserved.
//

#import "TFTAdMobInterstitial.h"

@interface TapForTapAdMobInterstitial : TFTAdMobInterstitial

@end

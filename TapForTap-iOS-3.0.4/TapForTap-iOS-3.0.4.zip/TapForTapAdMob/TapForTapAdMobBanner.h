//
//  Copyright (c) 2013 Tap for Tap. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TFTAdMobBanner.h"

@interface TapForTapAdMobBanner : TFTAdMobBanner

@end
